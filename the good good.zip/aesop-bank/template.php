<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Aesop Financial</title>
    <link href="/favicons/favicon-32x32.png" rel="icon" type="image/x-icon" />
    <link rel="stylesheet" href="/css/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  </head>
  <body>
    <a href="/"><img id="logo" src="/imgs/logo_transparent.png" alt="Aesop Logo"></a>
    <div id="header">
      <ul>
        <li><a href="/" class="current" title="Aesop Home">Home</a></li>
        <li><a href="/#login" class="" title="Login to your Aesop account">Login</a></li>
        <li><a href="/contact" title="Contact us">Contact</a></li>

      </ul>
    </div>

    <div id="body">
      <h1>Lorem Ipsum</h1>
      <p>Insert Stuff here.</p>
    </div>

    <div id="footer">
      <p>Copyright &copy; 2018, Aesop Financial, All Rights Reserved.</p>
    </div>
  </body>
</html>
