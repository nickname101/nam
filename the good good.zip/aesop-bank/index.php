<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Aesop Financial</title>
    <link href="/favicons/favicon-32x32.png" rel="icon" type="image/x-icon" />
    <link rel="stylesheet" href="/css/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  </head>
  <body>
    <a href="/"><img id="logo" src="/imgs/logo_transparent.png" alt="Aesop Logo"></a>
    <div id="header">
      <ul>
        <li><a href="/" title="Aesop Home">Home</a></li>
        <li><a href="/#login" title="Login to your Aesop account">Login</a></li>
        <li><a href="/contact" title="Contact us">Contact</a></li>


      </ul>
    </div>

    <div id="body">
      <h1>Welcome to Aesop Financial.</h1>
      <p>Since we started operating since 1993, and we have taken pride in our security! We always use our <br>
        patent- pending Universal Protection Diverse Override Generator (UPDOG) to encrypt your data from <br>
        any evil-doers who may try to hack your ip. </p>
      <div id="login">
        <p style="font-weight:bold;font-size:18px;">To get started, login to your Aesop account: </p>
        <form action="/account/action.php" method="post">
          <input type="text" name="user" placeholder="Username">
          <input type="password" name="pass" placeholder="Password">
          <input type="submit" name="submit" class="button" value="Login">
        </form>
      </div>
    </div>
    <div id="body">
      <h1>To Get Started:</h1>
      <p>Go to your nearest Aesop Financial Kiosk and ask for an account. They will ask you "What is the air <br>
      speed velocity of a unladen swallow?" Reply with "An African or European swallow?"</p>
    </div>

    <div id="footer">
      <p>Copyright &copy; 2018, Aesop Financial, All Rights Reserved.</p>
    </div>
  </body>
</html>
