<?php

  if (isset($_POST["submit"])) {
    $user = $_POST["user"];
    $pass = $_POST["pass"];
    if ($user == "jsmith" and $pass == "password1") {
      header("Location: /account/?a=D6upZBGPij");
    } else {
      header("Location: /?error=invalid");
    }
  } else {
    header("Location: /");
    die();
  }

?>
