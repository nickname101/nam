<?php

if ($_GET["a"]= "D6upZBGPij") {
  echo '<!DOCTYPE html>
  <html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <title>Aesop Financial</title>
      <link href="/favicons/favicon-32x32.png" rel="icon" type="image/x-icon" />
      <link rel="stylesheet" href="/css/styles.css">
      <link rel="stylesheet" href="/css/tables.css">
      <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    </head>
    <body>
      <a href="/"><img id="logo" src="/imgs/logo_transparent.png" alt="Aesop Logo"></a>
      <div id="header">
        <ul>
          <li><a href="/" class="current" title="Aesop Home">Home</a></li>
          <li><a href="/#login" class="" title="Login to your Aesop account">Login</a></li>
          <li><a href="/contact" title="Contact us">Contact</a></li>

        </ul>
      </div>

      <div id="body">
        <h1>Welcome back, James Smith.</h1>
        <hr>
        <h1 style="font-size:35px;">Accounts</h1>
        <table>
            <thead>
              <tr>
                <th>Type</th>
                <th>Account Number</th>
                <th>Current Balance</th>
                <th>Available Balance</th>
              </tr>
            </thead>
          <tbody>
            <tr>
              <td>Checking</td>
              <td>********1337</td>
              <td>$9,000.01</td>
              <td>$9,000.01</td>
            </tr>
            <tr>
              <td>Savings</td>
              <td>********1738</td>
              <td>$16,420.83</td>
              <td>$16,420.83</td>
            </tr>
            <tr>
              <td>Platinum AARP Credit Card</td>
              <td>********1603</td>
              <td>$422.71</td>
              <td>$25,000.00</td>
            </tr>
            <tr>
              <td>Roth IRA</td>
              <td>********3048</td>
              <td>$90,012.03</td>
              <td>$92,394.12</td>
            </tr>
            <tr>
              <td>Fixed Rate War Bond</td>
              <td>********1787</td>
              <td>$9,029.10</td>
              <td>$9,029.10</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div id="footer">
        <p>Copyright &copy; 2018, Aesop Financial, All Rights Reserved.</p>
      </div>
    </body>
  </html>
';
} else {
  header("Location: /");
}

 ?>
